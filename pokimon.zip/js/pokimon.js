const botonMascotaJugador = document.getElementById('boton-mascota')
const spanMascotaJugador = document.getElementById('mascotapropia')
const spanMascotaRival = document.getElementById('mascotarival')
const spanVictoriaPropia = document.getElementById('vidapropia')
const spanVictoriaRival = document.getElementById('vidarival')
const botonReiniciar = document.getElementById('botonReiniciar')
const seccionMensajes = document.getElementById('resultado')
const ataquesDelJugador = document.getElementById('ataquesDelJugador')
const ataquesDelrival = document.getElementById('ataquesDelRival')
const contenedorTarjetas = document.getElementById('contenedorPokimones')
const contenedorDeAtaques = document.getElementById('contenedorAtaques')

let pokimones =[]
let victoriaPropia = 0
let victoriaRival = 0
let opcionDePokimones
let opcionDeAtaques
let inputMudkip
let inputTreecko
let inputTorchic
let botonFuego
let botonAgua 
let botonPlanta 
let botones = []
let mascotaPropia
let iAtaqueJugador
let iAtaqueRival
let ataquesJugador = []
let ataquesPokimonRival = []
let ataquePokimonRival = []
let resultado

class Pokimon{
    constructor(nombre, foto, vida) { 
        this.nombre = nombre
        this.foto = foto
        this.vida = vida
        this.ataques = []
    }
}

let pokimonMudkip = new Pokimon('Mudkip', './assets/mudkip.png', 5)

let pokimonTreecko = new Pokimon('Treecko', './assets/treecko.png', 5)

let pokimonTorchic = new Pokimon('Torchic', './assets/torchic.png',5)

pokimonMudkip.ataques.push(
    {nombre:'💧', id: 'boton-agua'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'💧', id: 'boton-agua'},
    {nombre:'🍃', id: 'boton-planta'}
)

pokimonTreecko.ataques.push(
    {nombre:'🍃', id: 'boton-planta'},
    {nombre:'🍃', id: 'boton-planta'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'💧', id: 'boton-agua'}

)
pokimonTorchic.ataques.push(
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🍃', id: 'boton-planta'},
    {nombre:'💧', id: 'boton-agua'},
    {nombre:'🔥', id: 'boton-fuego'}
)

pokimones.push(pokimonMudkip,pokimonTreecko,pokimonTorchic)

pokimones.forEach((Pokimon) => {
    opcionDePokimones = `
    <input type="radio" name="mascota" id=${Pokimon.nombre} />
    <label class="tarjetaDePokimon" for=${Pokimon.nombre}>
        <p>${Pokimon.nombre}</p>
        <img src=${Pokimon.foto} alt=${Pokimon.nombre}>
    </label>
    `
    contenedorTarjetas.innerHTML += opcionDePokimones

    inputMudkip = document.getElementById('Mudkip')
    inputTreecko = document.getElementById('Treecko')
    inputTorchic = document.getElementById('Torchic')
})

botonMascotaJugador.addEventListener('click',seleccionarMascotaJugador)
botonReiniciar.style.display = 'none'
botonReiniciar.addEventListener('click',reiniciar)

function seleccionarMascotaJugador(){
    if(inputMudkip.checked){
        spanMascotaJugador.innerHTML = inputMudkip.id
        mascotaPropia = inputMudkip.id
    } else if(inputTreecko.checked){
        spanMascotaJugador.innerHTML = inputTreecko.id
        mascotaPropia = inputTreecko.id
    } else if(inputTorchic.checked ){
        spanMascotaJugador.innerHTML = inputTorchic.id
        mascotaPropia = inputTorchic.id
    } else
        alert("selecciona mascota")
    inputMudkip.id.disabled =true
    inputTreecko.id.disabled =true
    inputTorchic.id.disabled =true
    botonMascotaJugador.disabled = true

    extraerAtaques(mascotaPropia)
    seleccionarMascotaRival()
}

function extraerAtaques(mascotaPropia){
    let ataques
    for (let i = 0; i < pokimones.length; i++) {
        if (mascotaPropia == pokimones[i].nombre){
            ataques = pokimones[i].ataques
        }
    }
    mostrarAtaques(ataques)
}

function mostrarAtaques(ataques){
    ataques.forEach((ataque) => {
        opcionDeAtaques = `
        <button id=${ataque.id} class="botonesDeAtaque">${ataque.nombre} </button>`
        contenedorDeAtaques.innerHTML += opcionDeAtaques
    })
    botonFuego = document.getElementById('boton-fuego')
    botonAgua = document.getElementById('boton-agua')
    botonPlanta = document.getElementById('boton-planta')
    botones = document.querySelectorAll('.botonesDeAtaque')
}

function secuenciaAtaques() {
    botones.forEach((boton) => {
        boton.addEventListener('click', (e) => {
            if (e.target.textContent === '🔥') {
                ataquesJugador.push('Fuego')
                console.log(ataquesJugador)
                boton.style.background = 'black'
                boton.disabled = true
            } else if (e.target.textContent  == '💧') {
                ataquesJugador.push ('Agua')
                console.log(ataquesJugador)
                boton.style.background = 'black'
                boton.disabled = true
            } else {
                ataquesJugador.push ('Planta')
                console.log(ataquesJugador)
                boton.style.background = 'black'
                boton.disabled = true
            }
            seleccionAtaqueRival()
        })
    })
}

function seleccionarMascotaRival(){
    let mascotaRival = aleatorio(0, pokimones.length -1)

    spanMascotaRival.innerHTML = pokimones[mascotaRival].nombre
    ataquesPokimonRival = pokimones[mascotaRival].ataques
    secuenciaAtaques()
}
function aleatorio(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
}

function seleccionAtaqueRival(){
    ataqueRival= aleatorio(0,ataquesPokimonRival.length -1)
    if(ataqueRival === 0 || ataqueRival === 1){
        ataquePokimonRival.push ("Fuego")
        console.log(ataquePokimonRival)
    } else if (ataqueRival === 2){
        ataquePokimonRival.push ("Agua")
        console.log(ataquePokimonRival)
    } else{
        ataquePokimonRival.push ("Planta")
        console.log(ataquePokimonRival)
    }
    iniciarPelea()
}

function iniciarPelea(){
    if (ataquesJugador.length == 4) {
        combate()
    }
}

function crearMensajeFinal(resultadoFinal){
    let seccionMensajes = document.getElementById('resultado')
    if (victoriaPropia == victoriaRival) {
        seccionMensajes.innerHTML = ("Empate")
    } else if ( victoriaPropia > victoriaRival){
        seccionMensajes.innerHTML = ("Ganaste")
    } else {
        seccionMensajes.innerHTML = ("Perdiste")
    }
}

function iAmbosOponentes(jugador, rival){
    iAtaqueJugador = ataquesJugador[jugador]
    iAtaqueRival = ataquePokimonRival[rival]
}

function combate(){

    for (let i = 0; i < ataquesJugador.length; i++) {
        if(ataquesJugador[i] == ataquePokimonRival[i] ){
            iAmbosOponentes(i, i)
            crearMensaje()
        } else if ((ataquesJugador[i] == "Fuego"  && ataquePokimonRival[i] == "Planta") || (ataquesJugador[i] == "Agua" && ataquePokimonRival[i] == "Fuego") || (ataquesJugador[i] == "Planta" && ataquePokimonRival[i] == "Agua")) {
            iAmbosOponentes(i, i)
            crearMensaje()
            victoriaPropia++
            spanVictoriaPropia.innerHTML =victoriaPropia
        } else {
            iAmbosOponentes(i, i)
            crearMensaje()
            victoriaRival++
            spanVictoriaRival.innerHTML =victoriaRival
        }
    } crearMensajeFinal()
}
function crearMensaje(){

    let nuevoAtaqueDelJugador = document.createElement('p')
    let nuevoAtaqueDelRival = document.createElement('p')

    nuevoAtaqueDelJugador.innerHTML = iAtaqueJugador
    nuevoAtaqueDelRival.innerHTML = iAtaqueRival

    ataquesDelJugador.appendChild(nuevoAtaqueDelJugador)
    ataquesDelrival.appendChild(nuevoAtaqueDelRival)
}

function reiniciar(){
    location.reload()
}